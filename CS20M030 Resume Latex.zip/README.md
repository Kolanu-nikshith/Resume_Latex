ResumeTemplate
==============

A Latex template for resumes in institute standard format. Update: Fixed remaining bugs.
